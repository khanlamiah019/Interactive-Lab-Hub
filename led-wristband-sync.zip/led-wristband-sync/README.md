# LED Wristband Sync

Laptop analyzes a song's frequencies in real time and streams matching colors
to your phone over your local WiFi network — no internet required once set up.

## One-time setup

1. Install [Node.js](https://nodejs.org) if you don't have it.
2. Unzip this folder, open a terminal inside it, and run:
   ```
   npm install
   ```

## Every time you want to run the show

1. Start the server:
   ```
   node server.js
   ```
   It will print two URLs, something like:
   ```
   On THIS laptop, open:
     http://localhost:3000/control.html

   On your PHONE (same WiFi network), open:
     http://192.168.1.42:3000/display.html
   ```
2. On your **laptop**, open the `control.html` URL.
3. On your **phone**, open the `display.html` URL (must be on the same WiFi network as the laptop — phone hotspot/guest networks with "client isolation" won't work).
4. On the laptop page, choose your audio file (you'll need your own copy of the song — this doesn't fetch or stream it for you).
5. Start/End are pre-set to 190 and 210 seconds (3:10–3:30). Adjust if needed.
6. Press **Start Show**. The laptop plays the clip, analyzes it, and the phone's screen changes color in sync — red when bass-heavy, blue when treble-heavy, purple in between, with a brightness flash on beat drops.

## Notes

- If your phone can't reach the laptop's IP, check that both devices are on the same WiFi network and that your laptop's firewall allows incoming connections on port 3000.
- You can open `display.html` on more than one phone at once — they'll all sync together.
- Colors are computed from the song's actual frequency spectrum, not hardcoded — this will work with any audio file, not just this one song.
