const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const WebSocket = require('ws');

const PORT = 3000;

const MIME = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.css': 'text/css'
};

const server = http.createServer((req, res) => {
  let filePath = req.url === '/' ? '/control.html' : req.url;
  filePath = path.join(__dirname, 'public', filePath);

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end('Not found');
      return;
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
});

const wss = new WebSocket.Server({ server });

// Relay: anything one client sends gets broadcast to every other connected client.
// (Laptop sends color/start/end messages; phone just listens.)
wss.on('connection', (ws) => {
  ws.on('message', (msg) => {
    // Force relay as text — otherwise Buffer data gets forwarded as a
    // binary frame and JSON.parse() on the receiving side silently fails.
    const text = msg.toString();
    wss.clients.forEach((client) => {
      if (client !== ws && client.readyState === WebSocket.OPEN) {
        client.send(text);
      }
    });
  });
});

server.listen(PORT, () => {
  console.log(`\nServer running.\n`);
  console.log(`On THIS laptop, open:`);
  console.log(`  http://localhost:${PORT}/control.html\n`);
  console.log(`On your PHONE (same WiFi network), open one of these:`);
  const ifaces = os.networkInterfaces();
  let found = false;
  Object.values(ifaces).flat().forEach((iface) => {
    if (iface && iface.family === 'IPv4' && !iface.internal) {
      console.log(`  http://${iface.address}:${PORT}/display.html`);
      found = true;
    }
  });
  if (!found) {
    console.log('  (Could not detect a local network IP automatically — run "ifconfig" or "ipconfig" to find it.)');
  }
  console.log('');
});
